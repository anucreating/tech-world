# E-Learning_Platform

## Overview
E-learning is an education via the Internet, network, or standalone computer. E-learning is basically the network- enabled convey of skills and knowledge. E-learning refers to using electronic applications and processes to learn. E-learning includes all forms of electronically supported learning and teaching. E-learning applications and processes include Web-based learning, computer-based learning, virtual education opportunities and digital collaboration.

### Website : (Static View)


https://shubham-sutar.github.io/E-Learning_Platform/


### Our Services

1. **Free Courses.**
2. **Programming Hub.**
3. **E-Books.**


## Screen Shots

![Screenshot (841)](https://user-images.githubusercontent.com/68117385/128470683-110304c4-2af1-4f65-ad6a-c0110982ad93.png)

